export const SUPABASE_CONFIG = {
  url: 'https://dikcvsvxwyxadkmptfgq.supabase.co',
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRpa2N2c3Z4d3l4YWRrbXB0ZmdxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzkxMTYwMjgsImV4cCI6MjA1NDY5MjAyOH0.aAo6-CUfzFnAusCQ5D1Og6PqYf0FSxBX1wMCSxcfAIs'
};