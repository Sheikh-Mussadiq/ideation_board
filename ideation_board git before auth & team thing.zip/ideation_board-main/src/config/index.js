export const API_CONFIG = {
  ACCESS_TOKEN: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiaW50ZXJuYWxUZXN0IiwiYWNjb3VudElkIjoiNTYyMGVjMTYzNTFlNmVhMTZhODU2MjQwIn0.Sxu46_mFTnC9ZPSAr_xm1FJ8S4B-FXEtpD3ljJgEk7M',
  BASE_URL: 'https://automation-api.socialhub.io/cp/posts',
  CONTENT_URL: 'https://api.socialhub.io/cp/content',
  HEADERS: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Origin': 'https://stackblitz.com',
    'Cache-Control': 'no-cache'
  }
};